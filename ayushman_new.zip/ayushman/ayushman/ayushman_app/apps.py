from django.apps import AppConfig


class AyushmanAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ayushman_app'
