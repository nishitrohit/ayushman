from importlib.util import set_loader
from django.db import models
import qrcode
from io import BytesIO
from django.core.files import File
from PIL import Image, ImageDraw
from django.http import HttpResponse
from django.template.loader import render_to_string
from weasyprint import HTML
from django.core.files.base import ContentFile

# Create your models here.
class ayushman(models.Model):
    pmjay_id = models.CharField(max_length=100,blank=True,null=True)
    name = models.CharField(max_length=60,blank=True,null=True)
    yob = models.CharField(max_length=60,blank=True,null=True)
    abha_no = models.CharField(max_length=60,blank=True,null=True)
    gender = models.CharField(max_length=20,blank=True,null=True)
    samagra_id = models.CharField(max_length=60,blank=True,null=True)
    mobile_number = models.CharField(max_length=60,blank=True,null=True)
    city = models.CharField(max_length=60,blank=True,null=True)
    sub_division = models.CharField(max_length=100,blank=True,null=True)
    district = models.CharField(max_length=50,blank=True,null=True)
    type = models.CharField(max_length=50,blank=True,null=True)
    image = models.FileField(upload_to='image/', null=True, blank=True)
    qr_code = models.ImageField(upload_to='qr_codes/', blank=True,null=True)
    is_card = models.IntegerField(blank=True, null=True, default=0)
    card = models.FileField(upload_to='card/', null=True, blank=True)

    def __str__(self):
        return str(self.name)


    def save(self, *args, **kwargs):
        # qrcode_img1 = qrcode.make({'name':self.pmjay_id])
        qrcode_img1 = qrcode.make({'name':self.name,'gender':self.gender,'pmjay id':self.pmjay_id,'yob':self.yob,
                                      'samagra id':self.samagra_id,'abha no':self.abha_no})

        canvas2 = Image.new('RGB', (550, 550), 'white')
        canvas2.paste(qrcode_img1)
        fname = f'qr_code-{self.name}.png'
        buffer = BytesIO()
        canvas2.save(buffer,'PNG')
        self.qr_code.save(fname, File(buffer), save=False)
        canvas2.close()
        super().save(*args, **kwargs)
 
        
        # Call the scheduled task function with the next ID

class ayushman_main(models.Model):

    pmrssm_id = models.CharField(max_length=100,blank=True,null=True)
    name_ben = models.CharField(max_length=100,blank=True,null=True)
    dob_ben = models.CharField(max_length=100,blank=True,null=True)
    gender_ben = models.CharField(max_length=100,blank=True,null=True)
    rural_urban = models.CharField(max_length=100,blank=True,null=True)
    doc_pic = models.FileField(upload_to='image/', null=True, blank=True)
    ahl_hhid = models.CharField(max_length=100,blank=True,null=True)
    ahl_tin = models.CharField(max_length=100,blank=True,null=True)
    aabha_id = models.CharField(max_length=100,blank=True,null=True)
    source_of_data = models.CharField(max_length=100,blank=True,null=True)
    DistrictName = models.CharField(max_length=100,blank=True,null=True)
    LocalBody = models.CharField(max_length=100,blank=True,null=True)
    VillageName = models.CharField(max_length=100,blank=True,null=True)
    qr_code = models.ImageField(upload_to='qr_codes/', blank=True,null=True)
    is_card = models.IntegerField(blank=True, null=True, default=0)
    card = models.FileField(upload_to='card/', null=True, blank=True)
    def __str__(self):
        return str(self.name_ben)


    def save(self, *args, **kwargs):
        # qrcode_img1 = qrcode.make({'name':self.pmjay_id])
        qrcode_img1 = qrcode.make({'name':self.name_ben,'gender':self.gender_ben,'pmjay id':self.pmrssm_id,'yob':self.dob_ben,
                                      'samagra id':self.ahl_hhid,'abha no':self.aabha_id})

        canvas2 = Image.new('RGB', (550, 550), 'white')
        canvas2.paste(qrcode_img1)
        fname = f'qr_code-{self.name_ben}.png'
        buffer = BytesIO()
        canvas2.save(buffer,'PNG')
        self.qr_code.save(fname, File(buffer), save=False)
        canvas2.close()
        super().save(*args, **kwargs)
