from django.contrib import admin
from django.urls import path
from ayushman_app.views import ayushman_new

urlpatterns = [
    
    path("ayushman_new/", ayushman_new.as_view()),
    # path('ayushman_card/<int:id>', views.ayushman_card, name='ayushman_card'),


]    


    



    

    

    

    

    

    

