
from django_crontab import CronJobBase, Schedule
from .models import ayushman
from django.template.loader import render_to_string
from weasyprint import HTML
from django.core.files.base import ContentFile
from django.shortcuts import render
from django_crontab import crontab
from .views import ayushman_new

# from django_q.tasks import async_task


# def hello_world_task():
#     print("Hello, World!")

# class MyCronJob():
#     RUN_EVERY_MINS = 1  # run every 1 minutes

#     schedule = Schedule(run_every_mins=RUN_EVERY_MINS)
# #     code = 'your_app.your_cron_job'  # a unique code to identify your cron job

#     def do(self):
#         ayushman_new()

def MyCronJob(request):
    ayushman_new()
