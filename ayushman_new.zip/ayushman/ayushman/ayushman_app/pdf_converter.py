def html_to_pdf(data,csurl):
        print(data)
        print(csurl)
        html_content = '''<!DOCTYPE html>
        <html lang="en">
        <head>
                <title>Ayushman Card</title>
                <meta charset="utf-8" />
                <meta name="viewport" content="width=device-width, initial-scale=1" />
                 
                 


        

              

        </head>
        
        <body>
        <table  style="width:100%;border:1px solid #000">
    <tr>
       <td style="padding: 60px; border:1px solid #000">
          <table  style="width:100%;">
             <tr>
                <td>
                    <div class="ayushmanbody_img">   
                        <img src="/static/assets/images/bocwbody1.jpg" class="img-fluid">
                    </div>

                    <div class="header-block" style="background: black; height: 165px; opacity: 0; z-index: 999;position: relative;"> 
                    </div>

                    <table class="bodys-item-block" style="width: 100%;">
                        <tr class="flexbox-block">
                            <td style="width: 25%;">
                                <div style="border:1px solid #000">
                                    <img src="data:image/jpeg;base64," class="img-fluid" alt="image not found">
                                </div>
                            </td>
                            <td class="content-block" style="width: 50%;" >
                                <table style="width: 100%;" class="cinfo-block">
                                    <tr>
                                        <td style="width: 100%;" colspan="2">
                                            <div class="form-group">
                                                <label class="d-block" style="display:block;color:#e9590e">  नाम/Name </label>
                                                <h4>'''+data.name+'''</h4>
                                            </div>         
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="width: 50%;">
                                            <div class="form-group">
                                                <label class="d-block" style="display:block;color:#e9590e"> 
                                                जन्म वर्ष /YOB :
                                                <span style="padding-left:5px;color:#000;">'''+data.yob+''' </span>
                                                </label>
                                             </div>   
                                        </td> 
                                        <td style="width: 50%;">
                                            <div class="form-group">
                                               <label class="d-block" style="display:block;color:#e9590e"> 
                                               लिंग / GENDER :
                                               <span style="padding-left:5px;color:#000;">'''+data.gender+'''</span>
                                               </label>
                                            </div>
                                        </td> 
                                    </tr>
            
                                    <tr>
                                        <td style="width: 100%;" colspan="2">
                                            <div class="form-group">
                                                <label class="d-block" style="display:block;color:#e9590e"> 
                                                गांव / शहर /Village/ Town :
                                                <span style="padding-left:5px;color:#000;">'''+data.city+''' </span>
                                                </label>
                                             </div>       
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="width: 100%;" colspan="2">
                                            <div class="form-group">
                                                <label class="d-block" style="display:block;color:#e9590e"> 
                                                गांव / शहर /Village/ Town :
                                                <span style="padding-left:5px;color:#000;">'''+data.city+''' </span>
                                                </label>
                                             </div>       
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="width: 100%;" colspan="2">
                                            <div class="form-group">
                                               <label class="d-block" style="display:block;color:#e9590e"> 
                                               तालुका / Subdivision :
                                               <span style="padding-left:5px;color:#000;">'''+data.sub_division+''' </span>
                                               </label>
                                            </div>      
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="width: 100%;" colspan="2">
                                            <div class="form-group">
                                               <label class="d-block" style="display:block;color:#e9590e"> 
                                               ज़िला / District :
                                               <span style="padding-left:5px;color:#000;">'''+data.district+''' </span>
                                               </label>
                                            </div> 
                                        </td>
                                    </tr>
                                </table>   
                            </td>

                            <td class="content-block" style="width: 25%;">
                                <div style="border:1px solid #000; padding:4px;">
                                    <img src="data:image/jpeg;base64," class="img-fluid" alt="image not found">
                                </div>
                                <br>
                                <div class="form-group form-group2">
                                    <label class="d-block" style="display:block;color:#e9590e; text-align: right;"> 
                                    राज्य :
                                    <b class="pl-2"> मध्य प्रदेश  </b>
                                    </label>
                                 </div>
                                 <div class="form-group form-group2">
                                    <label class="d-block" style="display:block;color:#e9590e; text-align: right;"> 
                                        State :
                                        <b class="pl-2"> Madhya Pradesh </b>
                                    </label>
                                 </div> 
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
    </td>
</tr>
</table>

 
                    
 
 
        '''
        return html_content