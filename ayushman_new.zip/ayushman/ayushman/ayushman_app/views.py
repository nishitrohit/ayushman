from urllib import response
from django.shortcuts import render
from .models import ayushman,ayushman_main
from qrcode import *
from django.core.files import File
from django.core.files.base import ContentFile
from pikepdf import Pdf
from django.http import HttpResponse
from django.template.loader import render_to_string
from weasyprint import HTML
from django.conf import settings
import os
from urllib import request
from django.http import HttpRequest
# Create your views here.
# def ayushman_new(request):
#     ayushman_code = ayushman.objects.all().order_by('pmjay_id')
#     return render(request, 'ayushman_app/ayushman.html',{'data':ayushman_code})


# def ayushman_card(request,id):
#     ayushman_code = ayushman.objects.get(id=id)
#     ayushman_code.is_card = 1
#     ayushman_code.save()


#     template = 'ayushman_app/card_download.html'
#     context = {'data': ayushman_code }
#     html_string = render_to_string(template, context)
#     pdf_file = HTML(string=html_string).write_pdf()
#     my_object = ayushman.objects.get(pk=id)
#     my_object.card.save(my_object.pmjay_id, ContentFile(pdf_file))


#     return render(request,'ayushman_app/new_certificate.html',{'data':ayushman_code})


# def ayushman_card(request,id):
#     ayushman_code = ayushman.objects.get(id=id)
#     ayushman_code.is_card = 1
#     ayushman_code.save()
#     return render(request,'ayushman_app/new_certificate.html',{'data':ayushman_code})
# 
    # Perform actions with my_object

def process(id):
    ayushman_code = ayushman_main.objects.get(id=id)
    ayushman_code.is_card = 1
    ayushman_code.save()
    localhost = 'http://127.0.0.1:8000'
    request = HttpRequest()
    context = {'data': ayushman_code }
    html_string = render_to_string('ayushman_app/card_download.html', context)
    pdf_file = HTML(string=html_string, base_url=request.build_absolute_uri(localhost)).write_pdf()
    response = HttpResponse(pdf_file, content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="my_file.pdf"'
    my_object = ayushman_main.objects.get(id=id)
    my_object.card.save(my_object.pmjay_id, ContentFile(pdf_file))

   



from django.views import View

class ayushman_new(View):
    def get(self, request):
        items = ayushman_main.objects.all()

        batch_size = 5  # Specify the batch size 565604

        # Process items in batches
        for i in range(0, len(items), batch_size):
            batch = items[i:i+batch_size]

            for item in batch:
                process(item.id)  # Call the process() method for each item
            return HttpResponse("ok")
            # return render(request,'ayushman_app/new_certificate.html')
